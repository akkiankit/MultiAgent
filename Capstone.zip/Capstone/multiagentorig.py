import os
import re
import subprocess
import asyncio
from semantic_kernel.agents import AgentGroupChat, ChatCompletionAgent
from semantic_kernel.agents.strategies.termination.termination_strategy import TerminationStrategy
from semantic_kernel.agents.strategies.selection.kernel_function_selection_strategy import KernelFunctionSelectionStrategy
from semantic_kernel.connectors.ai.function_choice_behavior import FunctionChoiceBehavior
from semantic_kernel.connectors.ai.open_ai.services.azure_chat_completion import AzureChatCompletion
from semantic_kernel.contents.chat_message_content import ChatMessageContent
from semantic_kernel.contents.utils.author_role import AuthorRole
from semantic_kernel.kernel import Kernel
from semantic_kernel.functions import KernelFunctionFromPrompt
from semantic_kernel.contents import ChatHistoryTruncationReducer
from semantic_kernel.agents.strategies import KernelFunctionSelectionStrategy

from dotenv import load_dotenv
import nest_asyncio

nest_asyncio.apply()
load_dotenv()

# Agent names
BA = "BusinessAnalyst"
SE = "SoftwareEngineer"
PO = "ProductOwner"

# Git push function
def on_user_approved():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.abspath(os.path.join(script_dir, '../../push_to_github.sh'))
    commit_message = "Automated commit: User approved changes"

    git_bash_path = r"C:\Program Files\Git\bin\bash.exe"
    try:
        result = subprocess.run(
            [git_bash_path, script_path, commit_message],
            capture_output=True,
            text=True
        )
        print(result.stdout)
        if result.stderr:
            print("Git push stderr:", result.stderr)
    except Exception as e:
        print(f"Error during Git push: {e}")

# Agent Personas
business_analyst_persona = """
You are a Business Analyst which will take the requirements from the user (also known as a 'customer') 
and create a project plan for creating the requested app...
"""

software_engineer_persona = """
You are a Software Engineer. Build a web app using HTML/JavaScript based on the Business Analyst's requirements.
"""

product_owner_persona = """
You are the Product Owner. Review if Software Engineer’s code meets requirements.
IMPORTANT: If satisfied, say 'READY FOR USER APPROVAL'.
HTML code must be inside ```html ... ``` tags.
"""

# Stop condition: user says APPROVED
class ApprovalTerminationStrategy(TerminationStrategy):
    async def should_agent_terminate(self, agent, history):
        for message in history:
            if message.role == AuthorRole.USER and "APPROVED" in message.content.upper():
                return True
        return False

# Main multi-agent loop
async def run_multi_agent(input: str):
    kernel = Kernel()
    chat_service = AzureChatCompletion(
        deployment_name=os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    )
    kernel.add_service(chat_service)

    settings = kernel.get_prompt_execution_settings_from_service_id("default")
    settings.function_choice_behavior = FunctionChoiceBehavior.Auto()

    # Create agents
    ba = ChatCompletionAgent(name=BA, instructions=business_analyst_persona, kernel=kernel)
    se = ChatCompletionAgent(name=SE, instructions=software_engineer_persona, kernel=kernel)
    po = ChatCompletionAgent(name=PO, instructions=product_owner_persona, kernel=kernel)

    # Define selection strategy
    selection_function = KernelFunctionFromPrompt(
        function_name="selection",
        prompt=f"""Examine the provided RESPONSE and choose the next participant.
State only the name of the chosen participant without explanation.
Never choose the participant named in the RESPONSE.

Participants:
- {BA}
- {SE}
- {PO}
- USER

Rules:
- If RESPONSE is user input, it's {BA}'s turn.
- If RESPONSE is by {BA}, it's {SE}'s turn.
- If RESPONSE is by {SE}, it's {PO}'s turn.
- If RESPONSE is by {PO} and contains 'READY FOR USER APPROVAL', it's USER's turn.
- If RESPONSE is by {PO} and does NOT contain 'READY FOR USER APPROVAL', it's {SE}'s turn.

RESPONSE:
{{{{$lastmessage}}}}""",
    )

    history_reducer = ChatHistoryTruncationReducer(target_count=3)

    selection_strategy = KernelFunctionSelectionStrategy(
        initial_agent=ba,
        function=selection_function,
        kernel=kernel,
        history_variable_name="lastmessage",
        result_parser=lambda result: str(result.value[0]).strip(),
        history_reducer=history_reducer,
    )

    group_chat = AgentGroupChat(
        agents=[ba, se, po],
        selection_strategy=selection_strategy,
        termination_strategy=ApprovalTerminationStrategy()
    )

    conversation = []
    first_msg = ChatMessageContent(role=AuthorRole.USER, content=input)
    await group_chat.add_chat_message(first_msg)
    conversation.append({"role": "user", "content": input})

    try:
        async for response in group_chat.invoke():
            if response is None:
                continue

            print(f"{response.role} - {response.name}: {response.content}")
            conversation.append({"role": response.role, "content": response.content})

            if response.role == AuthorRole.ASSISTANT and "READY FOR USER APPROVAL" in response.content.upper():
                print("🔍 Awaiting user approval...")
                approved_msg = ChatMessageContent(role=AuthorRole.USER, content="APPROVED")
                await group_chat.add_chat_message(approved_msg)
                conversation.append({"role": "user", "content": "APPROVED"})

            if response.role == AuthorRole.USER and "APPROVED" in response.content.upper():
                print("✅ Approval received. Proceeding to save and push code...")

                full_history = " ".join([msg["content"] for msg in conversation])
                match = re.search(r"```html\s*(.*?)\s*```", full_history, re.DOTALL)

                if match:
                    html_code = match.group(1)
                    with open("index.html", "w", encoding="utf-8") as f:
                        f.write(html_code)
                    print("💾 index.html saved.")
                    on_user_approved()
                    print("🚀 Code pushed to GitHub.")
                else:
                    print("❌ No HTML code found in conversation.")
                break

    except Exception as e:
        print(f"❌ Error during chat: {e}")
        conversation.append({"role": "error", "content": str(e)})

    return {"messages": conversation}
