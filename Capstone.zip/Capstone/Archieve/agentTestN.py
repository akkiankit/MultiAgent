import os
import asyncio
from semantic_kernel.agents import AgentGroupChat, ChatCompletionAgent
from semantic_kernel.agents.strategies.termination.termination_strategy import TerminationStrategy
from semantic_kernel.agents.strategies.selection.kernel_function_selection_strategy import (KernelFunctionSelectionStrategy,)
from semantic_kernel.connectors.ai.function_choice_behavior import FunctionChoiceBehavior
from semantic_kernel.connectors.ai.open_ai.services.azure_chat_completion import AzureChatCompletion
from semantic_kernel.contents.chat_message_content import ChatMessageContent
from semantic_kernel.contents.utils.author_role import AuthorRole
from semantic_kernel.kernel import Kernel


import re
import subprocess
# class ApprovalTerminationStrategy(TerminationStrategy):
#     """A strategy for determining when an agent should terminate."""
#     async def should_agent_terminate(self, agent, history):
#         """Check if the agent should terminate."""
#         return NotImplementedError("Code to be implemented by the student")
    
# # 
# async def run_multi_agent(input: str):
#     """implement the multi-agent system."""
#     return responses
class ApprovalTerminationStrategy(TerminationStrategy):
    """A strategy for determining when an agent should terminate."""

    async def should_agent_terminate(self, agent, history):
        """Check if the agent should terminate."""
        for message in history:
            if "APPROVED" in message.content:
                return True
        return False

    # Businesss Analyst Persona
business_analyst_persona = """
    You are a Business Analyst which will take the requirements from the user (also known as a 'customer') 
    and create a project plan for creating the requested app. The Business Analyst understands the user 
    requirements and creates detailed documents with requirements and costing. The documents should be 
    usable by the SoftwareEngineer as a reference for implementing the required features, and by the 
    Product Owner for reference to determine if the application delivered by the Software Engineer meets 
    all of the user's requirements.
    """

 # Software Engineer Persona
software_engineer_persona = """
    You are a Software Engineer, and your goal is create a web app using HTML and JavaScript by taking 
    into consideration all the requirements given by the Business Analyst. The application should 
    implement all the requested features. Deliver the code to the Product Owner for review when completed. You can also ask questions of the BusinessAnalyst to clarify any requirements that are unclear.
    """

 # Product Owner Persona
product_owner_persona = """
    You are the Product Owner which will review the software engineer's code to ensure all user requirements 
    are completed. You are the guardian of quality, ensuring the final product meets all specifications. 
    IMPORTANT: Verify that the Software Engineer has shared the HTML code using the format ```html [code] ```. 
    This format is required for the code to be saved and pushed to GitHub. Once all client requirements 
    are completed and the code is properly formatted, reply with 'READY FOR USER APPROVAL'. If there are 
    missing features or formatting issues, you will need to send a request back to the SoftwareEngineer 
    or BusinessAnalyst with details of the defect.
    """

async def run_multi_agent(input: str):
    """Implement the multi-agent system."""
    # -----------------------------------------------------------------------
    kernel = Kernel()
    business_analyst_agent = ChatCompletionAgent(
        name = "BusinessAnalyst",
        # description= "Analyzes user requirements and creates detailed documnetation",
        instructions= business_analyst_persona,
        kernel=kernel
    )

    software_engineer_agent = ChatCompletionAgent(
        name = "SoftwareEngineer",
        # description= "Develops software based on requirements from the Business Analyst",
        instructions= software_engineer_persona,
        kernel=kernel
    )
   
    product_owner_agent = ChatCompletionAgent(
        name= "ProductOwner",
        # description="Reviews software code and ensures all requirements are met.",
        instructions= product_owner_persona,
        kernel=kernel
    )


    #  # Create an ExecutionSettings with a TerminationStrategy
    # execution_settings = ExecutionSettings(
    #     termination_strategy=ApprovalTerminationStrategy()
    # )

       # Create an AgentGroupChat with the agents and the execution settings
    group_chat = AgentGroupChat(
        agents=[business_analyst_agent, software_engineer_agent, product_owner_agent],
        # execution_settings=execution_settings
    )

    # Example logic to illustrate termination and post-processing:
    if await execution_settings.termination_strategy.should_agent_terminate(None, group_chat.history):
        # Extract HTML code
        html_code = None
        for message in group_chat.history:
            if "```html" in message.content:
                html_code = re.search(r"```html(.*?)```", message.content, re.DOTALL).group(1).strip()
                break

        if html_code:
            # Save HTML code to a file
            with open('index.html', 'w') as file:
                file.write(html_code)
            
            # Push to GitHub
            subprocess.run(['bash', 'push_to_github.sh'], check=True)

    return group_chat.history



import asyncio

async def test_multi_agent():
    input_message = "Start the project planning."
    history = await run_multi_agent(input_message)
    
    # Print the chat history for review
    print("Chat History:")
    for message in history:
        print(f"{message.role}: {message.content}")

# Run the asynchronous test function
asyncio.run(test_multi_agent())