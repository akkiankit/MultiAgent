import os
import asyncio

from semantic_kernel.agents import AgentGroupChat, ChatCompletionAgent
from semantic_kernel.agents.strategies.termination.termination_strategy import TerminationStrategy
from semantic_kernel.agents.strategies.selection.kernel_function_selection_strategy import (KernelFunctionSelectionStrategy,)
from semantic_kernel.connectors.ai.function_choice_behavior import FunctionChoiceBehavior
from semantic_kernel.connectors.ai.open_ai.services.azure_chat_completion import AzureChatCompletion
from semantic_kernel.contents.chat_message_content import ChatMessageContent
from semantic_kernel.contents.utils.author_role import AuthorRole
from semantic_kernel.kernel import Kernel
import subprocess


################################################################################################
class BusinessAnalystAgent(ChatCompletionAgent):
    def __init__(self, kernel):
        super().__init__(kernel)
        self.name = "BusinessAnalyst"
        self.instructions = (
            "You are a Business Analyst. Take requirements from the user and create a project plan. "
            "Create detailed documents with requirements and costing for the Software Engineer and Product Owner."
        )
    
    async def respond_to(self, input):
        requirements = f"Received requirements from customer: {input}"
        project_plan = "Project Plan: Includes detailed requirements and costing."
        return f"{requirements}\n{project_plan}"

class SoftwareEngineerAgent(ChatCompletionAgent):
    def __init__(self, kernel):
        super().__init__(kernel)
        self.name = "SoftwareEngineer"
        self.instructions = (
            "You are a Software Engineer. Create a web app using HTML and JavaScript based on Business Analyst's requirements. "
            "Deliver the code to the Product Owner for review."
        )
    
    async def respond_to(self, input):
        code = """html
        <html>
        <head><title>Web App</title></head>
        <body>
            <!-- Features implemented -->
        </body>
        </html>
        """
        return f"Implemented features based on requirements:\n{code}"

class ProductOwnerAgent(ChatCompletionAgent):
    def __init__(self, kernel):
        super().__init__(kernel)
        self.name = "ProductOwner"
        self.instructions = (
            "You are the Product Owner. Review the software engineer's code to ensure all user requirements are met. "
            "Verify that the code is shared using the format ```html [code] ```. "
            "Reply 'READY FOR USER APPROVAL' if everything is correct."
        )
    
    async def respond_to(self, input):
        if "```html" in input:
            return "READY FOR USER APPROVAL"
        else:
            return "Code missing or improperly formatted. Please ensure HTML code is shared using the format ```html [code] ```."

class ApprovalTerminationStrategy(TerminationStrategy):
    async def should_agent_terminate(self, agent, history):
        for message in history:
            if message.role == AuthorRole.USER and "APPROVED" in message.content:
                return True
        return False
    
# Instantiate the Kernel object
kernel = Kernel()

# Instantiate each agent with the Kernel object
business_analyst = BusinessAnalystAgent(kernel)
software_engineer = SoftwareEngineerAgent(kernel)
product_owner = ProductOwnerAgent(kernel)

# Create the AgentGroupChat
agent_group_chat = AgentGroupChat(
    agents=[business_analyst, software_engineer, product_owner],
    execution_settings=ExecutionSettings(
        termination_strategy=ApprovalTerminationStrategy()
    )
)

def on_approved_callback(history):
    html_code = ""
    for message in history:
        if "```html" in message.content:
            html_code = message.content.split("```html")[1].split("```")[0]
            break

    with open("index.html", "w") as file:
        file.write(html_code)

    # Call the Bash script to push changes
    subprocess.run(["bash", "push_to_github.sh"])

async def run_multi_agent(input: str):
    responses = await agent_group_chat.process(input)
    
    if agent_group_chat.execution_settings.termination_strategy.should_agent_terminate(None, responses):
        on_approved_callback(responses)

    return responses



if __name__ == "__main__":
    # Run the multi-agent workflow with a sample input
    asyncio.run(run_multi_agent("Start the project with the following requirements..."))

######################################################################
# class ApprovalTerminationStrategy(TerminationStrategy):
#     """A strategy for determining when an agent should terminate."""
 
#     async def should_agent_terminate(self, agent, history):
#         """Check if the agent should terminate."""
#         return NotImplementedError("Code to be implemented by the student")


# async def run_multi_agent(input: str):
#     """implement the multi-agent system."""
#     return responses